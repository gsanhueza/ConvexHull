# Instrucciones de compilación

* Abrir terminal
* Ir a carpeta `build` (crearla si no existe)
* Ejecutar `cmake ..`
* Ejecutar `make`
* Ejecutar `./tarea_2`

# Notas

Esta tarea usa *lambdas*, por lo que se requiere un compilador con soporte para C++11.
(En particular esta tarea es compilable con GCC 6.3)
